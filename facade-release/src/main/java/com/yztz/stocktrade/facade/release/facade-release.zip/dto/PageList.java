/**
 * Yztz.com Inc.
 * Copyright (c) 2013-2015 All Rights Reserved.
 */

package com.yztz.stocktrade.facade.release.dto;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Liang Chenye
 * @version $Id: PageList, v 0.1 2015/6/29 17:28
 */

public class PageList<E> extends ArrayList<E> {

    private static final long serialVersionUID = 3906365987534414964L;

    private Paginator paginator;

    public PageList() {
        paginator = new Paginator(0);
    }

    public PageList(int size) {
        super(size);
        paginator = new Paginator(0);
    }

    public PageList(Collection<E> c) {
        this(c, null);
    }

    public PageList(Collection<E> c, Paginator paginator) {
        super(c);
        this.paginator = paginator;
    }

    public Paginator getPaginator() {
        return paginator;
    }

    public void setPaginator(Paginator paginator) {
        this.paginator = paginator;
    }

}
